// src/auth/auth.service.ts
import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService }       from '@nestjs/jwt';
import * as bcrypt           from 'bcrypt';

import { UsersService }     from '../users/users.service';
import { CreateUserDto }    from '../users/dto/create-user.dto';

@Injectable()
export class AuthService {
  constructor(
    private users: JwtService,      // JWT helper
    private usersService: UsersService,
    private jwt: JwtService,
  ) {}

  async register(dto: CreateUserDto) {
    // delegates to UsersService.create()
    return this.usersService.create(dto);
  }

  async validateUser(email: string, pass: string) {
    const user = await this.usersService.findByEmail(email);
    if (!user || !user.password) return null;
    const matches = await bcrypt.compare(pass, user.password);
    if (!matches) return null;
    // strip out password before returning
    const { password, ...safe } = user;
    return safe;
  }

  async login(user: any) {
    const payload = { sub: user.id, email: user.email, role: user.role };
    return {
      access_token: this.jwt.sign(payload),
      user:         payload,
    };
  }
}
