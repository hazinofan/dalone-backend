// src/auth/google.strategy.ts
import { Injectable }               from '@nestjs/common';
import { PassportStrategy }         from '@nestjs/passport';
import { Strategy, VerifyCallback } from 'passport-google-oauth20';
import { ConfigService }            from '@nestjs/config';
import { UsersService }             from '../users/users.service';

@Injectable()
export class GoogleStrategy extends PassportStrategy(Strategy, 'google') {
  constructor(
    private config: ConfigService,
    private usersService: UsersService,
  ) {
    super({
      clientID:     config.get('GOOGLE_CLIENT_ID'),
      clientSecret: config.get('GOOGLE_CLIENT_SECRET'),
      callbackURL:  `${config.get('BACKEND_URL')}/auth/google/callback`,
      scope:        ['email','profile'],
    });
  }

  async validate(
    accessToken: string,
    refreshToken: string,
    profile: any,
    done: VerifyCallback,
  ) {
    const email = profile.emails[0].value;
    let user = await this.usersService.findByEmail(email);

    if (!user) {
      // always create as "client"; we’ll upgrade later if needed
      user = await this.usersService.create({
        email,
        password: null,
        role: 'client',
      });
    }
    const { password, ...safeUser } = user as any;
    done(null, safeUser);
  }
}
