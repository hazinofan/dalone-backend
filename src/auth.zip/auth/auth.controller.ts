// src/auth/auth.controller.ts
import { Controller, Post, UseGuards, Request, Get, Res, Body, Req, Query } from '@nestjs/common';
import { AuthService } from './auth.service';
import { AuthGuard } from '@nestjs/passport';
import { CreateUserDto } from '../users/dto/create-user.dto';
import { Response } from 'express';
import { ConfigService } from '@nestjs/config';
import { RequestWithUser } from './types';
import { UsersService } from 'src/users/users.service';

@Controller('auth')
export class AuthController {
  constructor(
    private auth: AuthService,
    private config: ConfigService,
    private usersService: UsersService,    // for later
  ) { }

  // 1) Registration
  @Post('register')
  register(@Body() dto: CreateUserDto) {
    return this.auth.register(dto);
  }

  // 2) Email/password login
  @UseGuards(AuthGuard('local'))
  @Post('login')
  login(@Req() req: RequestWithUser) {
    return this.auth.login(req.user);
  }

  // Démarrage OAuth Google
  @Get('google')
  @UseGuards(AuthGuard('google'))
  googleLogin() { }

  // Callback OAuth Google
  @Get('google/callback')
  @UseGuards(AuthGuard('google'))
  async googleRedirect(
    @Req() req: RequestWithUser,
    @Res() res: Response,
  ) {
    const { access_token } = await this.auth.login(req.user);
    const front = this.config.get<string>('FRONTEND_URL');
    return res.redirect(`${front}/finish-joining?token=${access_token}`);
  }
} 
